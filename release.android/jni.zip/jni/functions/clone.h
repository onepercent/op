//
//  clone.h
//  v8
//
//  Created by jie on 13-8-23.
//  Copyright (c) 2013年 jie. All rights reserved.
//

#ifndef v8_clone_h
#define v8_clone_h

namespace globalfn {
    using namespace v8;
}

#endif
